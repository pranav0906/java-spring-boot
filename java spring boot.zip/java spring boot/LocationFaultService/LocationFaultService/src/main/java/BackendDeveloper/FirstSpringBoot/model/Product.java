package BackendDeveloper.FirstSpringBoot.model;


public class Product {
	private int ProductId;
	private String productName;
	public int getProductId() {
		return ProductId;
	}

	public void setProductId(int productId) {
		System.out.println("stored id");
		ProductId = productId;
	}

	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		System.out.println("stored name");

		this.productName = productName;
	}
	public Product() {
		super();
		// TODO Auto-generated constructor stub
		System.out.println("new product posted");	
		}
	public Product(int productId, String productName) {
		super();
		ProductId = productId;
		this.productName = productName;
	}
	@Override
	public String toString() {
		return "Product [ProductId=" + ProductId + ", productName=" + productName + "]"+" - "+ hashCode();
	}
}
