package BackendDeveloper.FirstSpringBoot.controllers;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import BackendDeveloper.FirstSpringBoot.model.Product;
import BackendDeveloper.FirstSpringBoot.service.productService;

@RestController
@RequestMapping("/shopping")
public class shopping {
	public long count=0;
	@Autowired
	productService service;
	public shopping() {
		System.err.println("controller created");
	}
	@RequestMapping(path="/",method=RequestMethod.GET)
	public String home() {
		count++;
		String response="<html><body><h1>";
		response+= "Welcome </h1><br>";
		response+="<b>your visit </b>"+count;
		response+="</body></html>";
		return response;
	}
	@GetMapping("/list")
	public HashMap<Integer,Product> getproductsList(){
		
		return service.getproductsList();
		
	}
	@GetMapping("/search")
	public String searchProduct(@RequestParam("pId") int productId) {
		return service.searchById(productId);
		
	}
	@DeleteMapping("/deleteId/{pId}")
	public String deleteProduct(@PathVariable("pId") int productId) {
		return service.deleteProduct(productId);
	
	}
	@PostMapping(path="/add", consumes=MediaType.APPLICATION_JSON_VALUE)
	public String addProduct(@RequestBody Product p) {
		System.out.println("post req");
		return service.addProduct(p);
		
		
	}
	@PutMapping(path="/update",consumes=MediaType.APPLICATION_JSON_VALUE)
	public String updateProduct(@RequestBody Product p ) {
		System.out.println("Updating..." + p.toString());
		
		return service.updateProduct(p.getProductId(),p.getProductName());
	}

}
