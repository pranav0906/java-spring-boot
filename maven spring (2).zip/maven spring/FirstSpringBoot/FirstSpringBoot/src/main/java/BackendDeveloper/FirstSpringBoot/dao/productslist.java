package BackendDeveloper.FirstSpringBoot.dao;

import java.util.HashMap;

import BackendDeveloper.FirstSpringBoot.model.Product;

public class productslist {
	public HashMap<Integer,Product> productsList=new HashMap();
	
	
	public String addProduct(Product p) {
		productsList.put(p.getProductId(),p);
		System.err.println("added new");
		return "<b>Succesfully added..</b>" + "use /list";
		
	}
	public HashMap<Integer,Product> getproductsList(){
		System.out.println("retrived list");
		return productsList;
		
	}
	public productslist(){
		productsList.put(0,new Product(0,"Sam"));
		productsList.put(1,new Product(1,"iphone"));
		productsList.put(2,new Product(2,"nexus"));
		System.err.println("list created");
	}
	public String deleteProduct(int productId) {
		Product pname=productsList.get(productId);
		if (pname!=null) {
			productsList.remove(productId);
			return "<b> Procuct Found and deleted</b>;"+pname;
		}
		else {
			return "<b>No Products</b>";	
			}
		
		
	}
	public String searchById(int productId) {
		Product pname=productsList.get(productId);
		if (pname!=null)
			return "<b> Procuct Found</b>;"+pname;
		else
			return "<b>No Products</b>";
		
	}
	public String updateProduct(int productId,String newProductName ) {
		System.out.println("PRODUCT ID : " + productId);
		if (productsList.containsKey(productId)) {
			Product p = productsList.get(productId);
			p.setProductName(newProductName);
			productsList.put(p.getProductId(),p);

		}
		else {
			System.out.println("No Products");
		}
		return "";
		
		
	}

}
