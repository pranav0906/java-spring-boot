package BackendDeveloper.FirstSpringBoot.service;

import java.util.HashMap;

import org.springframework.stereotype.Service;

import BackendDeveloper.FirstSpringBoot.dao.productslist;
import BackendDeveloper.FirstSpringBoot.model.Product;

@Service
public class productService {
	productslist plist=new productslist();

	public HashMap<Integer,Product> getproductsList(){
		System.out.println("getting list");
		return plist.getproductsList();		
	}
	public String addProduct(Product p) {
		System.out.println("adding");

		return plist.addProduct(p);
		
	
	}
	public String deleteProduct(int productId) {
		System.out.println("deleting list service");

		return plist.deleteProduct(productId);
		
		
	}
	public String searchById(int productId) {
		System.out.println("searching list service");

		return plist.searchById(productId);
		
	}
	public String updateProduct(int productId,String newProductName ) {
		System.out.println("updating list service");

		return plist.updateProduct(productId, newProductName);
		
	
		
	}

}
