package BackendDeveloper.FirstSpringBoot.dao;


import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import BackendDeveloper.FirstSpringBoot.model.*;
@Repository
public interface productslist extends  CrudRepository<Product, Integer> {

}
