package BackendDeveloper.FirstSpringBoot.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import BackendDeveloper.FirstSpringBoot.dao.productslist;
import BackendDeveloper.FirstSpringBoot.model.Product;

@Service
public class productService {
	@Autowired
	productslist plist;

	public ArrayList<Product> getproductsList(){
		System.out.println("getting list");
		return (ArrayList<Product>)plist.findAll();
	}
	public String addProduct(Product p) {
		System.out.println("adding");
		Product t=plist.save(p);
		return "<b>Added products</b>"+ t;

		
	
	}
	public String deleteProduct(int productId) {
		System.out.println("deleting list service");
		plist.deleteById(productId);
		return "<b>deleted products</b>"+productId;

		
		
	}
	public String searchById(int productId) {
		System.out.println("searching list service");
		Optional<Product> opt=plist.findById(productId);
		return "<b>searched products</b>"+ opt.get().toString();
 

		
	}
	public String updateProduct(int productId,String newProductName ) {
		System.out.println("updating list service");
		Product d=new Product(productId,newProductName);
		return "<b>updated products</b>"+ plist.save(d);

		
	
		
	}

}
