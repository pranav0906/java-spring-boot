package BackendDeveloper.FirstSpringBoot.controllers;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import BackendDeveloper.FirstSpringBoot.model.Product;
import BackendDeveloper.FirstSpringBoot.service.productService;

@RestController
@RequestMapping("/shopping")
public class shopping {
	public long count=0;
	@Autowired
	productService service;
	public shopping() {
		System.err.println("controller created");
	}
	@RequestMapping(path="/",method=RequestMethod.GET)
	public ModelAndView home() {
		ModelAndView mv=new ModelAndView();
		mv.setViewName("home");
		count++;
		mv.addObject("count",count);
		return mv;


	}
	@GetMapping("/list")
	public ModelAndView getproductsList(){
		ModelAndView mv=new ModelAndView();
		mv.setViewName("listProduct");
		mv.addObject("products",service.getproductsList());
		
		return mv;
		
	}
	@GetMapping("/search")
	public String searchProduct(@RequestParam("pId") int productId) {
		return service.searchById(productId);
		
	}
	@DeleteMapping("/deleteId/{pId}")
	public String deleteProduct(@PathVariable("pId") int productId) {
		return service.deleteProduct(productId);
	
	}
	@PostMapping(path="/addProduct")
	public ModelAndView addProduct(@ModelAttribute Product p) {
		ModelAndView mv=new ModelAndView();
		System.out.println("post req");
		Product t= service.addProduct(p);
		mv.setViewName("addedPrduct");
		mv.addObject("product", t);
		return mv;

		
		
	}
	@GetMapping(path="/add")
	public ModelAndView addP() {
		ModelAndView mv=new ModelAndView();
		mv.setViewName("addProduct");
		mv.addObject("Today",new java.util.Date().toString());
		count++;
		mv.addObject("vcount", count);
		return mv;
		
	}
	@PostMapping(path="/updateProduct")
	public ModelAndView updateProduct(@ModelAttribute Product p ) {
		ModelAndView mv=new ModelAndView();
		mv.setViewName("updatedProduct");
		Product t=service.updateProduct(p.getProductId(),p.getProductName());
		mv.addObject(t);
		return mv;
	}
	@GetMapping(path="/update")
	public ModelAndView updateP() {
		ModelAndView mv=new ModelAndView();
		mv.setViewName("updateProduct");
		return mv;
	}
}
