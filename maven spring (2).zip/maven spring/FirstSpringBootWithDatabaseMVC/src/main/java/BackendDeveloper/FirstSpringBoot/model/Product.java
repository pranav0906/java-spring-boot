package BackendDeveloper.FirstSpringBoot.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="Product")
public class Product {
	@Id
	//@GeneratedValue(strategy=GenerationType.AUTO)
	private int productId;
	@Column(name="productName")
	private String productName;
	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		System.out.println("stored id");
		this.productId = productId;
	}

	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		System.out.println("stored name");

		this.productName = productName;
	}
	public Product() {
		super();
		// TODO Auto-generated constructor stub
		System.out.println("new product posted");	
		}
	public Product(int productId, String productName) {
		super();
		this.productId = productId;
		this.productName = productName;
	}
	@Override
	public String toString() {
		return "Product [ProductId=" + productId + ", productName=" + productName + "]"+" - "+ hashCode();
	}
}
