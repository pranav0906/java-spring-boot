package com.controller.login;


import jakarta.servlet.ServletConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

/**
 * Servlet implementation class Score
 */
@WebServlet("/Scores")
public class Score extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private String playerName="Virat";
	public int totalscores=99;
	public List<String> teamlist=new ArrayList();

    /**
     * Default constructor. 
     */
    public Score() {
    	System.out.println("Servlet created....");    

    	// TODO Auto-generated constructor stub
    }

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init(ServletConfig config) throws ServletException {
		super.init(config);
    	System.out.println("Servlet initialized....");
    	// TODO Auto-generated method stub
	}

	/**
	 * @see Servlet#destroy()
	 */
	public void destroy() {
		super.destroy();
		System.out.println("Destroying Servlet on" + new java.util.Date());
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		super.service(request,response);
		System.out.println("Received a" + request.getMethod() + "request...");
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		PrintWriter pw = response.getWriter();
		totalscores +=6;
		
		pw.println("<html><body><h1>Hai RCB fan </h1>"
				+ playerName+" : "+ totalscores + " </body></html>");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String teamname=request.getParameter("teamName");
		String placename=request.getParameter("baseLocation");
		System.out.println(teamname+ " , "+placename);
		

	}

}
